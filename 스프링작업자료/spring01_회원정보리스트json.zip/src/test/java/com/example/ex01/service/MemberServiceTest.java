package com.example.ex01.service;

import static org.junit.Assert.*;

import javax.inject.Inject;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.example.ex01.model.dao.MemberDAO;
import com.example.ex01.model.dto.MemberDTO;

import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"file:src/main/webapp/WEB-INF/spring/**/root-context.xml"})
@Log4j
public class MemberServiceTest {

	@Inject
	MemberDAO testMember;
	
	@Test
	public void testList() {
		log.info("회원목록:"+testMember.list());

	}
	

	@Test
	public void testDetail() {
		log.info("회원정보:"+testMember.detail("test1"));
	}	
	
	
	
	
	/*
	 * @Test public void testDelete() { fail("Not yet implemented"); }
	 * 
	 * @Test public void testUpdate() { fail("Not yet implemented"); }
	 * 
	 * @Test public void testCheck_passwd() { fail("Not yet implemented"); }
	 */
}
