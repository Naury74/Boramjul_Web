package com.example.ex01.contoller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;


import javax.inject.Inject;


import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.ex01.service.MemberService;



import com.example.ex01.model.dao.MemberDAO;


@RequestMapping("/member/*")
@Controller
public class MemberController {
	
	@Inject
	MemberService dao;
	
	@RequestMapping("list.do")
	public String mysql_list(Model model) {
		
		List<MemberDAO> list = dao.list();
		model.addAttribute("list", list);
		return "member/list";
	}
	@RequestMapping(value= "test.do",method= RequestMethod.POST)
	public @ResponseBody List<MemberDAO> test(@RequestParam("name") String name) throws IOException{		
		System.out.println("test 서블릿");
		List<MemberDAO> list = new ArrayList<MemberDAO>();
		
		return list;
	
	}
	@RequestMapping("memberinfojson.do")
	public @ResponseBody List<MemberDAO> jsonTest(){		
		System.out.println("회워정보 json 서블릿");
		List<MemberDAO> list = dao.list();
		
		return list;
	
	}
	
}
