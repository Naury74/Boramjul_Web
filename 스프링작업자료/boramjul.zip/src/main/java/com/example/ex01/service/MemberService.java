package com.example.ex01.service;

import java.util.List;

import javax.servlet.http.HttpSession;

import com.example.ex01.model.dto.MemberDTO;

public interface MemberService {
	
	// 회원목록 조회 서비스
		public List<MemberDTO> list();
		// 회원가입 서비스
		public void insert(MemberDTO dto);
		// 회원정보 상세 정보 조회
		public MemberDTO detail(String id);
		// 회원정보 삭제 
		public void delete(String id);
		// 회원정보 수정
		public void update(MemberDTO dto);
		// 회원 아이디및 비밀번호 체크
		public boolean check_passwd(String id, String passwd);
		
		// 로그인 성공여부에 따라 session값 생성 
		public String loginCheck(MemberDTO dto, HttpSession session);
		public void logout(HttpSession session);

}
