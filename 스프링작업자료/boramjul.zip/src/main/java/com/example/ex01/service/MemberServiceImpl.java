package com.example.ex01.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.inject.Inject;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.example.ex01.model.dao.MemberDAO;
import com.example.ex01.model.dto.MemberDTO;

@Service
public class MemberServiceImpl implements MemberService {
	
	private static final Logger logger = LoggerFactory.getLogger(MemberServiceImpl.class);

	@Inject
	MemberDAO memberDao;
	
	@Override
	public List<MemberDTO> list() {
		return memberDao.list();
	}

	@Override
	public void insert(MemberDTO dto) {
		memberDao.insert(dto);

	}

	@Override
	public MemberDTO detail(String id) {
		return memberDao.detail(id);
	}

	@Override
	public void delete(String id) {
		memberDao.delete(id);
	}

	@Override
	public void update(MemberDTO dto) {
		memberDao.update(dto);
	}

	@Override
	public boolean check_passwd(String id, String passwd) {
		return memberDao.check_passwd(id, passwd);
	}

	@Override
	public String loginCheck(MemberDTO dto, HttpSession session) {
		String name = memberDao.loginCheck(dto);
		
		if (name != null) {
			
			//로그인이 성공이면 세션값 생성
			session.setAttribute("id", dto.getId());
			session.setAttribute("name", name);
		
			// logger.info("session : "+session.getAttribute("id"));
			// logger.info("session : " + session.getAttribute("name"));
			
		} 
		return name;
	}

	@Override
	public void logout(HttpSession session) {
		session.removeAttribute("id");
		session.removeAttribute("name");
		
		 logger.info("로그아웃 했을 경우 userid값 : "+session.getAttribute("id"));
		 logger.info("로그아웃 했을 경우 name값 : "+session.getAttribute("name"));

	}

}
