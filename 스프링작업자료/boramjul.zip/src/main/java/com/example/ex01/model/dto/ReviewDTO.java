package com.example.ex01.model.dto;

public class ReviewDTO {

}
