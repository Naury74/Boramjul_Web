package com.example.ex01.model.dto;

import lombok.Data;

@Data
public class BooksDTO {
	private String search;

}
