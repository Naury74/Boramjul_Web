package com.example.ex01.model.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import com.example.ex01.model.dto.MemberDTO;

@Repository
public class MemberDAOImpl implements MemberDAO {
	
	@Inject
	SqlSession sqlSession;

	@Override
	public List<MemberDTO> list() {
		return sqlSession.selectList("mysqlMember.list");
	}

	@Override
	public void insert(MemberDTO dto) {
		sqlSession.insert("mysqlMember.insert",dto);

	}

	@Override
	public MemberDTO detail(String id) {
		return sqlSession.selectOne("mysqlMember.detail",id);
	}

	@Override
	public void delete(String id) {
		sqlSession.delete("mysqlMember.delete",id);
	}

	@Override
	public void update(MemberDTO dto) {
		sqlSession.update("mysqlMember.update",dto);
	}

	@Override
	public boolean check_passwd(String id, String passwd) {
		boolean result = false;
		
		// mybatis에 2개이상 인자를 사용 할 수 없으므로 이경우는 dto or Map활용
		Map<String,String> map = new HashMap<String, String>();
		map.put("userid", id);
		map.put("passwd", passwd);
		
		// 아래와 같이 사용 할 수 없음
		//int count = sqlSession.selectOne("member.check_passwd", userid, passwd);
		
		int count = sqlSession.selectOne("mysqlMember.check_passwd", map);
		// 1이면 true, 0이면 false	
		if (count == 1) 
			result =  true;
		
		return result;
	}

	@Override
	public String loginCheck(MemberDTO dto) {
		return sqlSession.selectOne("mysqlMember.loginCheck",dto);
	}

}
