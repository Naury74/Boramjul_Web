package com.example.ex01.service;

import static org.junit.Assert.*;

import java.io.IOException;

import javax.inject.Inject;
import javax.servlet.http.HttpSession;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.example.ex01.model.dao.MemberDAO;
import com.example.ex01.model.dto.MemberDTO;

import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(locations = {"file:src/main/webapp/WEB-INF/spring/**/root-context.xml"})
@Log4j
public class MemberServiceTest {

	@Inject
	MemberDAO testMember;
	
	//@Test
	public void testInsert() {		
		MemberDTO dto = new MemberDTO();
		//데이터 형에 맞추어 MemberDTO에 담기
		dto.setPasswd("1234");
		dto.setName("단위테스트");
		dto.setEmail("test1234@test.com");
		dto.setPhone("010-2222-3333");
		dto.setSns(1);		
		dto.setBirth("2021-05-12");		
		//MemberrDAO 에 있는 insert 함수 실행
		testMember.insert(dto);
	}
    
	//@Test
	public void testloginCheck() {		
		MemberDTO dto = new MemberDTO();
		dto.setEmail("test1234@test.com");
		dto.setPasswd("1234");		
		String name = testMember.loginCheck(dto);
		System.out.println("name: "+name);
		
	}
		
	//@Test
	public void testupdate() {		
		MemberDTO dto = new MemberDTO();
		//데이터 형에 맞추어 MemberDTO에 담기
		dto.setPasswd("4321");
		dto.setName("수정테스트");
		dto.setEmail("test1234@test.com");
		dto.setPhone("010-2222-4444");		
		dto.setBirth("2021-05-25");
		testMember.update(dto);
	}
	
//	//@Test
//	public void testDetail() {
//		log.info("회원정보:"+testMember.detail("test1234@test.com"));
//	}	
//	
//	@Test
//	public void testdeletel() {
//			MemberDTO dto = new MemberDTO();
//			dto.setPasswd("4321");			
//			dto.setEmail("test1234@test.com");
//			testMember.delete(dto);
//			log.info("회원정보:"+testMember.detail("test1234@test.com"));
//	}	
	
	
	/*
	 * @Test public void testDelete() { fail("Not yet implemented"); }
	 * 
	 * @Test public void testUpdate() { fail("Not yet implemented"); }
	 * 
	 * @Test public void testCheck_passwd() { fail("Not yet implemented"); }
	 */
}
