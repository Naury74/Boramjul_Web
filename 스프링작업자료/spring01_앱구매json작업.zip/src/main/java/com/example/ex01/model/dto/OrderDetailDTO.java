package com.example.ex01.model.dto;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL)
public class OrderDetailDTO {
	
	private int detailnum;
	private int cartnum;
	private String prodnum;
	private String email;
	private String prodname;
	private String image;
	private int quantity;
	private int price;
	private int totalprice;
	private int review;
	private int delivery;
	private Date indate;

}
