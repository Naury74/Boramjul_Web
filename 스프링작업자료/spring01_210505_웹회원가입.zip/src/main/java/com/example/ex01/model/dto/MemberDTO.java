package com.example.ex01.model.dto;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

import lombok.Data;

@Data
@JsonInclude(JsonInclude.Include.NON_NULL) // json 처리 시 null값이 있으면 제외하고 처리
public class MemberDTO {
	private String id;
	private String passwd;
	private String name;
	private String email;
	private String phone;
	private int sns;
	private String birth;
	private String address;
	private int rank;
	private int totalprice;
	private Date joindate;
}

