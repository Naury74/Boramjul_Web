package com.example.ex01.model.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;

import com.example.ex01.model.dto.MemberDTO;
import com.example.ex01.service.MemberService;

@Repository
public class MemberDAO implements MemberService {

	@Inject
	SqlSession sql_Session;
	
	@Override
	public List<MemberDAO> list() {
		
		return sql_Session.selectList("mysqlMember.list");
	}

	@Override
	public void insert(MemberDTO dto) {
		sql_Session.insert("mysqlMember.insert", dto);		
	}

	@Override
	public MemberDTO detail(String userid) {
		return sql_Session.selectOne("mysqlMember.detail", userid);
	}

	@Override
	public void delete(String userid) {
		sql_Session.delete("mysqlMember.delete", userid);
	}

	@Override
	public void update(MemberDTO dto) {
		sql_Session.update("mysqlMember.update", dto);
	}

	@Override
	public boolean check_passwd(String userid, String passwd) {
		boolean result = false;
		Map<String, String> map = new HashMap<String, String>();
		map.put("userid", userid);
		map.put("passwd", passwd);
		
		int count = sql_Session.selectOne("mysqlMember.check_passwd", map);
		if(count==1) {
			result = true;
		}
		return result;
	}

}
