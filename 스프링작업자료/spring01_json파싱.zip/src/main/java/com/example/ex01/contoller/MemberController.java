package com.example.ex01.contoller;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.inject.Inject;

import org.springframework.format.datetime.joda.DateTimeParser;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.ResponseBody;

import com.example.ex01.service.MemberService;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import com.example.ex01.model.dao.MemberDAO;
import com.example.ex01.model.dto.MemberDTO;

import org.json.simple.parser.ParseException;

@RequestMapping("/member/*")
@Controller
public class MemberController {

	@Inject
	MemberService dao;

	@RequestMapping("list.do")
	public String mysql_list(Model model) {

		List<MemberDAO> list = dao.list();
		model.addAttribute("list", list);
		return "member/list";
	}

	@RequestMapping("memberinfojson.do")
	public @ResponseBody List<MemberDAO> jsonTest() {
		System.out.println("회워정보 json 서블릿");
		List<MemberDAO> list = dao.list();

		return list;

	}

	@RequestMapping(value = "jsonToParsing.do")
	public String test(Model model) throws IOException {
		System.out.println("jsonToParsing 서블릿");
		BufferedReader bufferedReader = null;
		String resultSet = null;

		String reurl = "http://www.boramjul.kro.kr/member/memberinfojson.do";
		URL url = new URL(reurl);
		bufferedReader = new BufferedReader(new InputStreamReader(url.openConnection().getInputStream(), "UTF-8"));
		resultSet = bufferedReader.readLine();		
		ArrayList<MemberDTO> list = new ArrayList<MemberDTO>();

		try {
			JSONParser jsonParser = new JSONParser();
			JSONArray jsonArray = (JSONArray) jsonParser.parse(resultSet);
			
			
			for(int i=0; i<jsonArray.size(); i++){ 
				JSONObject obj = (JSONObject) jsonArray.get(i);
				
				MemberDTO dto = new MemberDTO();
				
				dto.setId(obj.get("id").toString()); 
				dto.setPasswd(obj.get("passwd").toString());
				dto.setName(obj.get("name").toString());
				dto.setEmail(obj.get("email").toString());
				dto.setPhone(obj.get("phone").toString());
				
				int snsjson = Integer.parseInt(String.valueOf(obj.get("sns")));
				int genderjson = Integer.parseInt(String.valueOf(obj.get("gender")));
				int birthjson = Integer.parseInt(String.valueOf(obj.get("birth")));
				
				dto.setSns(snsjson);
				dto.setGender(genderjson);
				dto.setBirth(birthjson);
				
				dto.setAddress(obj.get("address").toString());
				
				int rankjson = Integer.parseInt(String.valueOf(obj.get("rank")));
				int totalpricejson = Integer.parseInt(String.valueOf(obj.get("totalprice")));
				dto.setRank(rankjson);
				dto.setTotalprice(totalpricejson);
				list.add(dto);
							
			 }
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		model.addAttribute("list", list);
		return "member/list2";

	}

}
