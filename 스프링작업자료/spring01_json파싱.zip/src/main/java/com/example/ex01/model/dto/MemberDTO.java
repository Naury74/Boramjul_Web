package com.example.ex01.model.dto;

import java.util.Date;

import com.fasterxml.jackson.annotation.JsonInclude;

import lombok.Data;

@Data
@JsonInclude
public class MemberDTO {
	private String id;
	private String passwd;
	private String name;
	private String email;
	private String phone;
	private int sns;
	private int gender;
	private int birth;
	private String address;
	private int rank;
	private int totalprice;
	private Date joindate;
}

