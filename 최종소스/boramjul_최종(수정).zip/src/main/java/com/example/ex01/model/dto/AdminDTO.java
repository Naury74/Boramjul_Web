package com.example.ex01.model.dto;

import lombok.Data;

@Data
public class AdminDTO {
	private String id;
	private String passwd;
	private String name;
	private String email;
	private String phone;
	

}
